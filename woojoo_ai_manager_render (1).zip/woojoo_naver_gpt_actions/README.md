# 우주수니 AI 매니저

Render에 배포하는 개인용 웹앱입니다. OpenAI Responses API 대화와 네이버 검색, 네이버 DataLab 검색어 트렌드, 네이버 캘린더 OAuth/일정 등록 기능을 포함합니다.

## 포함 기능

- 비밀번호 로그인 방식의 개인 대시보드
- OpenAI API 기반 한국어 AI 대화
- AI가 필요할 때 네이버 뉴스·블로그·웹문서·카페글·지식iN 검색 도구 호출
- 네이버 DataLab 검색어 트렌드 조회
- 네이버 캘린더 OAuth 연결 및 일정 등록
- GPT Actions용 OpenAPI 스키마: `openapi.yaml`

## 배포 전 준비

1. GitHub에서 새 저장소를 만듭니다. 이름은 `woojoo-ai-manager`, 공개 범위는 **Private**를 권장합니다.
2. 이 ZIP의 `woojoo_naver_gpt_actions` 폴더 안 파일 전체를 저장소 루트에 올립니다.
3. Render에서 **New + → Blueprint**를 선택하고 GitHub 저장소를 연결합니다.
4. Render가 요구하는 비밀 환경변수 값을 입력합니다.
5. 배포가 끝나면 `https://서비스주소/health`에 접속해 `status: ok`를 확인합니다.
6. `BASE_URL`과 `NAVER_REDIRECT_URI`를 실제 Render 주소에 맞춥니다. 예: `https://woojoo-ai-manager.onrender.com` 및 `https://woojoo-ai-manager.onrender.com/oauth/naver/callback`
7. 네이버 개발자센터 애플리케이션의 네이버 로그인 Callback URL에도 동일한 콜백 주소를 등록합니다.
8. 앱 주소에 접속해 `APP_PASSWORD`로 로그인합니다. 네이버 캘린더 연결은 대시보드의 연결 버튼을 누르고 권한 동의를 진행합니다.

## Render 환경변수

| 변수 | 값 |
|---|---|
| `OPENAI_API_KEY` | OpenAI Platform에서 발급한 API 키 |
| `OPENAI_MODEL` | 기본 `gpt-4.1-mini` |
| `APP_PASSWORD` | 웹앱 로그인 비밀번호 |
| `SESSION_SECRET` | Render가 자동 생성 |
| `NAVER_CLIENT_ID` | 네이버 개발자센터 Client ID |
| `NAVER_CLIENT_SECRET` | 네이버 개발자센터 Client Secret |
| `GPT_ACTION_API_KEY` | Render가 자동 생성 |
| `BASE_URL` | 배포된 서비스의 HTTPS 주소 |
| `NAVER_REDIRECT_URI` | `BASE_URL` + `/oauth/naver/callback` |
| `TOKEN_DB_PATH` | 무료 플랜 기본값 `/tmp/naver_tokens.sqlite3` |

**보안:** API 키와 비밀번호를 소스 코드, GitHub 파일, 채팅 메시지에 넣지 마세요. Render의 Environment 설정에만 입력하세요. `OPENAI_API_KEY`는 ChatGPT 구독과 별도로 OpenAI API 사용료가 발생할 수 있습니다.

## 무료 플랜 관련 제한

현재 설정은 별도 결제 없이 시작할 수 있도록 Render Free로 구성했습니다. 무료 서비스는 일정 시간 미사용 시 중지될 수 있고 로컬 파일이 영구 보존되지 않습니다. 따라서 네이버 캘린더 OAuth 토큰은 서비스 재시작·재배포 후 사라질 수 있어 다시 연결해야 할 수 있습니다. 캘린더 연결을 안정적으로 유지하려면 영구 디스크가 지원되는 유료 인스턴스/스토리지가 필요하지만, 이 프로젝트는 사용자의 별도 승인 없이 유료 리소스를 생성하지 않습니다.

## 로컬 실행 (Windows)

```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
```

`.env`에 값을 입력하고 로컬에서는 `COOKIE_SECURE=false`로 설정한 뒤 실행합니다.

```bat
uvicorn app.main:app --reload
```

## GPT Actions 연결

`openapi.yaml`을 GPT Actions의 OpenAPI 스키마로 가져옵니다. 인증은 API Key 방식, 사용자 지정 헤더 이름은 `X-API-Key`로 설정하고 Render 환경변수 `GPT_ACTION_API_KEY`의 값을 입력합니다. 이 키는 공개하거나 대화에 붙여 넣지 마세요.

## 현재 범위 및 확인 사항

- 이 패키지는 배포 가능한 애플리케이션 코드와 설정을 제공합니다. Render 배포 및 실제 API 키를 사용한 실연동은 사용자의 계정에서 환경변수를 설정한 뒤 검증해야 합니다.
- 네이버 API 앱의 등록 상태, API 이용 권한 및 호출 한도는 네이버 개발자센터에서 확인해야 합니다.
- 앱은 단일 비밀번호 기반 개인용 MVP입니다. 다중 사용자 서비스로 공개하기 전에는 계정별 권한과 OAuth 토큰 분리를 구현해야 합니다.
